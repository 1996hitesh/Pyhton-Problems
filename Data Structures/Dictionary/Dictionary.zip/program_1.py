#Write a program to add a key and value to a dictionary.

Dict1 = {0: 10, 1: 20}
Dict1[2]=30    #adding the key value pair
print(Dict1)
