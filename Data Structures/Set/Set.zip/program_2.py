#Write a program to create an intersection of sets.

A = {0, 2, 4, 6, 8}
B = {1, 2, 3, 4, 5}
# intersection
print("Intersection :", A & B)
