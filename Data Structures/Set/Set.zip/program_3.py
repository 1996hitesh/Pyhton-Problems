# Write a program to create an union of sets.

A = {0, 2, 4, 6, 8}
B = {1, 2, 3, 4, 5}
# Union
print("Union :", A | B)
