#Write a program to find the maximum and minimum value in a set.

A = {0, 2, 4, 6, 8}
print("Minimum Value: ",min(A))
print("Maximum Value: ",max(A))
