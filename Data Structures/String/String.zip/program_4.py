s = input("Enter the string: ")
new_s = s.replace('x','')
print(new_s)
