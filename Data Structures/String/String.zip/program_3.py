s = input("Enter the string: ")
new_s = (s[0]+s[1])*len(s)
print(new_s)
