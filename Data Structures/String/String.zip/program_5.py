s = input("Enter the string: ")
n = int(input("Enter the value of n: "))
new_s = s[n-1:]*n
print(new_s)
