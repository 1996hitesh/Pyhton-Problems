#Write a program to append a new item to the end of the list.

my_list = [1,2,5,45,50]
my_list.append(51)    #appending new item at the end
print(my_list)
