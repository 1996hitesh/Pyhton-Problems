#Write a program to insert a new item before the second element in an existing list.

mylist = [0,1,2]
mylist.insert(1,4)
print(mylist)
