#write a program to remove the item from a specified index in a list.

x =int(input("Enter index"))
del mylist[x]
print(mylist)
