#Write a program to reverse the order of the items in the list.

my_list = [1,2,5,45,50]
my_list.reverse()
print(my_list)
