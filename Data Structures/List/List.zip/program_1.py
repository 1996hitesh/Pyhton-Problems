#Write a program to create a list of 5 integers and display the list items.
#Access individual elements through index.

my_list = [1,2,5,45,50]     #list of 5 integers

#Accessing the list item individually
print(my_list[0])
print(my_list[1])
print(my_list[2])
print(my_list[3])
print(my_list[4])
