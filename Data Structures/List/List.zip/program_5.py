#Write a program to append the items of list1 to list2 in the front.

list_1 = [0,1,2]
list_2 = ['a','b','c']
list_1.extend(list_2)
print(list_1)
