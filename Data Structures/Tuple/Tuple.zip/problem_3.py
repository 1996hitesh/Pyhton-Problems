# Write a program to convert a list into a tuple.

my_list = [1,2,3,4,5,6]

#converting the list into tuple
tup = tuple(my_list)
print("tup is type of: ",type(tup))
