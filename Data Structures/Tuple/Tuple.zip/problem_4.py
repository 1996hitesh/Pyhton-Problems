#Write a program to find the index of an item in a tuple.

t_1 = (1,2,3,4,5,6,7,8,9,10)
x = int(input("Enter element whose index to be search: "))
index = t_1.index(x)
print("Index of the element is: ",index)
