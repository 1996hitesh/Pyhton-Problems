# Write a program to print the 4th element from first
#and 4th element from last in a tuple.

t_1 = (1,2,3,4,5,6,7,8,9,10)        #initializing a tuple
print("4th element from the front = ",t_1[3])
print("4th element from the back = ",t_1[-4])
