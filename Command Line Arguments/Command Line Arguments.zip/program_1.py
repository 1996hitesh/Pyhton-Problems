#Write a program to accept two numbers as command line arguments
#and display their sum

from sys import argv

a = int(argv[1])
b = int(argv[2])
sum = a+b
print(sum)
