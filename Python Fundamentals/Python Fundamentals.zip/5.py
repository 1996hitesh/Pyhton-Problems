for i in range(23,57,1):
  if i%2 == 0:
      print(i)
