x = int(input("Enter First Number"))
y = int(input("Enter Second Number"))
if x%10 == y%10:
  print("true")
else:
  print("false")
