x = int(input("Enter the number: "))
if x%2 != 0:
  print("Odd number")
else:
  print("Even number")
