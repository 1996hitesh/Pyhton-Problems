x = int(input("Enter the number: "))
if x>0:
  print("Number is positive")
elif x<0:
  print("Number is negetive")
else:
  print("Number is zero")
