file = open("Test.txt")
content = file.readlines()
print(content)
file.close()
